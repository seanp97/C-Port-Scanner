using System.Diagnostics;
using System.Net.Sockets;

namespace PortScanner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.Columns.Add("portColumn", "OPEN PORTS");
            dataGridView1.DefaultCellStyle.Font = new Font("Segoe Fluent Icons", 13);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Task.Factory.StartNew(() => Scan());
        }

        void Scan()
        {

            try
            {

                string ip = textBox1.Text;

                int portOpenCount = 0;

                int portLimit = 0;

                if(textBox2.Text != "" && Convert.ToInt32(textBox2.Text) <= 65535 && Convert.ToInt32(textBox2.Text) != Single.NaN)
                {
                    portLimit = Convert.ToInt32(textBox2.Text);
                }
                else
                {
                    portLimit = 65535;
                }
                

                for (int i = 1; i <= portLimit; i++)
                {

                    using (TcpClient Scan = new TcpClient())
                    {

                        try
                        {
                            Scan.ReceiveTimeout = 10;

                            bool portCheck = Scan.ConnectAsync(ip, i).Wait(1);

                            if (portCheck)
                            {
                                dataGridView1.Invoke((MethodInvoker)(() => dataGridView1.Rows.Add(i.ToString())));
                                portOpenCount++;
                                label1.Invoke((MethodInvoker)(() => label1.Text = "PORTS OPEN: " + portOpenCount.ToString()));
                            }
                        }


                        catch(Exception)
                        {
                            continue;
                        }

                    }

                    int percentComplete = (int)Math.Round((double)(100 * i) / portLimit);
                    label3.Invoke((MethodInvoker)(() => label3.Text = "CURRENT PORT: " + i.ToString() + " / " + portLimit.ToString()));
                    label5.Invoke((MethodInvoker)(() => label5.Text = "PERCENT COMPLETED: " + percentComplete.ToString() + "%"));

                }

                MessageBox.Show("Scan completed");
            }

            catch (Exception)
            {
                
            }
               
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Task.Factory.StartNew(() => RefreshPort());
        }

        void RefreshPort()
        {
            Application.Restart();
            Environment.Exit(0);
        }
    }
}